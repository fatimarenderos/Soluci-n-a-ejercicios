import Foundation
// Ejer 5

var resultado: String? = nil
var nombre = "Fatima"
var mes = "Febrero"
var edad = "20"
var anno = "2020"
var dia = "14"
var profesion = "estudiante"
var bandera = false
var espannol  = nombre + edad + dia + mes + anno + profesion 
var ingles =  nombre + edad + dia + mes + anno + profesion 

if !bandera {
     resultado =  espannol
    if var newResultado = resultado{
   print( "En espannol  \(newResultado)    ")
    bandera = true
}}
else{
      resultado =  ingles
    if var newResultado = resultado{
    print( "En ingles \(newResultado)    ")
    bandera = false
}}


