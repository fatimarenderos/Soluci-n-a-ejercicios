import Foundation

// Ejer 2
var a = 5
var b = 3
var total=( a*a) + (2*a*b) + (b*b)
print (total)