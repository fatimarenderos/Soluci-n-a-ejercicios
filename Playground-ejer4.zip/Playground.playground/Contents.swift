import Foundation
// Ejer 4

var sws = [false, false, false, false, false]
var buscador = sws

for fa  in 0...4{
    print("Encendiendo switch \(fa + 1)")
    
    sws[fa] = true

    if((sws[0] && sws[1]) && (sws[0] || sws[2])) || (!sws[3] || (sws[4] && !sws[2])) && (sws[1] || sws[0]){
        print("Circuito encendido \n")
    }
    else{
        print("Circuito apagado \n")
        buscador[fa] = true
    }

    sws[fa] = false
}

for fa in 0...4{
    if(buscador[fa]){
        print("Encender solo el switch \(fa + 1) no enciende el circuito completo")
    }
}