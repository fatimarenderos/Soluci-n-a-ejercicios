import Foundation

// Ejer 1
var value:Int  = 2
if value  % 2 == 00 {
    print("\(value) es par")
} else {
    print("\(value) es impar")
}
