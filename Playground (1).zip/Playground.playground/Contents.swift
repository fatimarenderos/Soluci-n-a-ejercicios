import Foundation

// Ejer 1
var value:Int  = 2
if value  % 2 == 00 {
    print("\(value) es par")
} else {
    print("\(value) es impar")
}

// Ejer 2
var a = 5
var b = 3
var total=( a*a) + (2*a*b) + (b*b)
print (total)


// Ejer 3
let radio = 4
let pi=3.14159
let area = (pi * Double(radio) *  Double(radio))
print("El area del circulo con diametro 8 es \(area) ")

let perimetro = (2 * pi * Double(radio))
print("El perimetro del circulo con diametro 8 es \(perimetro) ")

// Ejer 4 opcion 1


var sws = [false, false, false, false, false]
var buscador = sws

for r in 0...4{
    print("encendiendo los interruptores \(r + 1)")
    
    sws[r] = true

    if((sws[0] && sws[1]) && (sws[0] || sws[2])) || (!sws[3] || (sws[4] && !sws[2])) && (sws[1] || sws[0]){
        print("Circuito modo on \n")
    }
    else{
        print("Circuito modo off \n")
        buscador[r] = true
    }

    sws[r] = false
}

for r in 0...4{
    if(buscador[r]){
        print("Encender solo el interruptor \(r + 1) no se enciende el circuito completo")
    }
}


// Ejer 4 opcion 2


var sw1 = false
var sw2 = false 
var sw3 = false
var sw4 = false
var sw5 = false
if ((sw1 && sw2) && (sw1 && sw3) || (!sw4 || sw5 && !sw3)) {
print("encendido")
}
else {
  print("apagado")  
}


// Ejer 5

var resultado: String? = nil
var nombre = "Fatima"
var mes = "Febrero"
var edad = "20"
var anno = "2020"
var dia = "14"
var profesion = "estudiante"
var bandera = false
var espannol  = nombre + edad + dia + mes + anno + profesion 
var ingles =  nombre + edad + dia + mes + anno + profesion 

if !bandera {
     resultado =  espannol
    if var newResultado = resultado{
   print( "En espannol  \(newResultado)    ")
    bandera = true
}}
else{
      resultado =  ingles
    if var newResultado = resultado{
    print( "En ingles \(newResultado)    ")
    bandera = false
}}

