import Foundation

let radio = 4
let pi=3.14159
let area = (pi * Double(radio) *  Double(radio))
print("El area del circulo con diametro 8 es \(area) ")

let perimetro = (2 * pi * Double(radio))
print("El perimetro del circulo con diametro 8 es \(perimetro) ")
